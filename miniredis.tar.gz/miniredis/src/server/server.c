/*
 * server.c  —  Person B
 *
 * Multi-threaded TCP server.
 * Each client connection is handled in its own detached pthread.
 * A global mutex serialises all Store access (one lock for the whole DB).
 *
 * Protocol framing
 * ----------------
 * Client sends: <command>\n
 * Server replies: <result>\r\nEND\n
 * The "END\n" sentinel lets the client know the full response has arrived.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>

#include "server.h"
#include "../engine/engine.h"
#include "../core/store/store.h"
#include "../commands/result.h"

#define RECV_BUF_SIZE 1024
#define SEND_BUF_SIZE 4096
#define BACKLOG       10
#define DEFAULT_STORE_SIZE 256

/* Shared database and its mutex */
static Store          *g_db;
static pthread_mutex_t g_db_lock = PTHREAD_MUTEX_INITIALIZER;

/* ------------------------------------------------------------------ */
/*  Per-client thread                                                   */
/* ------------------------------------------------------------------ */

typedef struct {
    int fd;
} ClientArg;

static void* handle_client(void *arg) {
    ClientArg *ca = (ClientArg*)arg;
    int client_fd = ca->fd;
    free(ca);

    char recv_buf[RECV_BUF_SIZE];

    while (1) {
        int n = recv(client_fd, recv_buf, sizeof(recv_buf) - 1, 0);
        if (n <= 0) break;   /* client disconnected or error */

        recv_buf[n] = '\0';
        /* strip trailing \r\n */
        recv_buf[strcspn(recv_buf, "\r\n")] = '\0';

        if (strlen(recv_buf) == 0) continue;

        /* run command under lock */
        pthread_mutex_lock(&g_db_lock);
        CommandResult res = run_command(g_db, recv_buf);
        pthread_mutex_unlock(&g_db_lock);

        /* build response: always non-NULL because result.c guarantees it */
        char send_buf[SEND_BUF_SIZE];
        const char *msg = res.message ? res.message : "";
        snprintf(send_buf, sizeof(send_buf), "%s\r\nEND\n", msg);

        send(client_fd, send_buf, strlen(send_buf), 0);
        freeResult(res);
    }

    close(client_fd);
    return NULL;
}

/* ------------------------------------------------------------------ */
/*  Main server loop                                                    */
/* ------------------------------------------------------------------ */

void start_server(int port) {
    g_db = init_engine(DEFAULT_STORE_SIZE);
    if (!g_db) {
        fprintf(stderr, "Failed to initialise store\n");
        exit(1);
    }

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket");
        exit(1);
    }

    /* allow quick restart without waiting for TIME_WAIT */
    int opt = 1;
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family      = AF_INET;
    addr.sin_port        = htons((uint16_t)port);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(server_fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(server_fd);
        exit(1);
    }

    if (listen(server_fd, BACKLOG) < 0) {
        perror("listen");
        close(server_fd);
        exit(1);
    }

    printf("Mini Redis server listening on port %d ...\n", port);

    while (1) {
        struct sockaddr_in client_addr;
        socklen_t          client_len = sizeof(client_addr);   /* fixed: was int */

        int client_fd = accept(server_fd,
                               (struct sockaddr*)&client_addr,
                               &client_len);
        if (client_fd < 0) {
            perror("accept");
            continue;
        }

        printf("Client connected: %s\n", inet_ntoa(client_addr.sin_addr));

        ClientArg *ca = (ClientArg*)malloc(sizeof(ClientArg));
        if (!ca) { close(client_fd); continue; }
        ca->fd = client_fd;

        pthread_t tid;
        if (pthread_create(&tid, NULL, handle_client, ca) != 0) {
            perror("pthread_create");
            free(ca);
            close(client_fd);
            continue;
        }
        pthread_detach(tid);
    }

    /* unreachable in normal operation */
    close(server_fd);
    destroy_engine(g_db);
}
