#ifndef SERVER_H
#define SERVER_H

/* Start the TCP server on the given port.
   Blocks indefinitely, handling clients in detached threads. */
void start_server(int port);

#endif
