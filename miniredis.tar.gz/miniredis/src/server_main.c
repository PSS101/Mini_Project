/*
 * server_main.c  —  TCP Server entry point
 *
 * Usage:  ./miniredis-server <port>
 *
 * The server restores state from miniredis.aof on startup if the file exists,
 * then appends every write command to the AOF for durability.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "server/server.h"
#include "engine/engine.h"
#include "persistence/aof.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        return 1;
    }

    int port = atoi(argv[1]);
    if (port <= 0 || port > 65535) {
        fprintf(stderr, "Invalid port: %s\n", argv[1]);
        return 1;
    }

    printf("Starting Mini Redis server on port %d\n", port);
    start_server(port);   /* blocks forever */
    return 0;
}
