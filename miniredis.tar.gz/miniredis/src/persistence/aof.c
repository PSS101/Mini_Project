/*
 * aof.c  —  Person C
 *
 * Append-Only File persistence layer.
 *
 * Write commands are appended one-per-line to a text file.
 * On startup, aof_load() replays every line through the dispatcher
 * to rebuild the in-memory store.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aof.h"
#include "../commands/dispatcher.h"
#include "../commands/result.h"
#include "../commands/parser.h"

/* Only these command names mutate state — we only persist these */
static const char *WRITE_CMDS[] = {
    "SET", "LPUSH", "RPUSH", "LPOP", "RPOP",
    "SADD", "HSET", "DEL", NULL
};

static FILE *g_aof = NULL;

/* ------------------------------------------------------------------ */

static int is_write_command(const char *cmd) {
    for (int i = 0; WRITE_CMDS[i] != NULL; i++) {
        if (strcmp(cmd, WRITE_CMDS[i]) == 0) return 1;
    }
    return 0;
}

int aof_open(const char *filepath) {
    g_aof = fopen(filepath, "a");   /* append mode — preserves existing log */
    if (!g_aof) {
        perror("aof_open");
        return -1;
    }
    return 0;
}

void aof_append(int argc, char *argv[]) {
    if (!g_aof || argc == 0) return;
    if (!is_write_command(argv[0])) return;

    /* Write: CMD arg1 arg2 ...\n
       Wrap tokens that contain spaces in double quotes */
    for (int i = 0; i < argc; i++) {
        int has_space = (strchr(argv[i], ' ') != NULL);
        if (has_space)
            fprintf(g_aof, "\"%s\"", argv[i]);
        else
            fprintf(g_aof, "%s", argv[i]);

        if (i < argc - 1) fprintf(g_aof, " ");
    }
    fprintf(g_aof, "\n");
    fflush(g_aof);   /* ensure durability after each write */
}

int aof_load(Store *store, const char *filepath) {
    FILE *f = fopen(filepath, "r");
    if (!f) return 0;   /* no AOF yet — fresh start */

    int   replayed = 0;
    char  line[1024];

    while (fgets(line, sizeof(line), f)) {
        /* strip trailing newline */
        line[strcspn(line, "\r\n")] = '\0';
        if (strlen(line) == 0) continue;

        char *tokens[MAX_TOKENS];
        int   argc = parse(line, tokens);
        if (argc <= 0) continue;

        /* replay through dispatcher (ignore result during load) */
        CommandResult res = execute(store, argc, tokens);
        freeResult(res);
        replayed++;
    }

    fclose(f);
    printf("[AOF] Replayed %d commands from %s\n", replayed, filepath);
    return replayed;
}

void aof_close(void) {
    if (g_aof) {
        fflush(g_aof);
        fclose(g_aof);
        g_aof = NULL;
    }
}
