/*
 * dev_cli.c  —  Person C
 *
 * In-process REPL: directly calls the engine (no TCP).
 * Supports optional AOF persistence:
 *   - On start:  loads existing AOF to restore state.
 *   - On write:  appends command to AOF.
 *   - On EXIT:   flushes and closes the AOF.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dev_cli.h"
#include "../engine/engine.h"
#include "../commands/result.h"
#include "../commands/parser.h"
#include "../persistence/aof.h"

#define MAX_INPUT 1024

void start_dev_cli(const char *aof_path) {
    Store *db = init_engine(256);
    if (!db) {
        fprintf(stderr, "Failed to initialise store\n");
        return;
    }

    /* Restore state from AOF if one exists */
    if (aof_path) {
        aof_load(db, aof_path);
        if (aof_open(aof_path) != 0) {
            fprintf(stderr, "Warning: could not open AOF for writing\n");
        }
    }

    char input[MAX_INPUT];
    printf("Mini Redis Dev CLI  (type EXIT to quit)\n");
    printf("Persistence: %s\n\n", aof_path ? aof_path : "disabled");

    while (1) {
        printf("mini-redis> ");
        fflush(stdout);

        if (!fgets(input, sizeof(input), stdin)) break;
        input[strcspn(input, "\r\n")] = '\0';

        if (strcmp(input, "EXIT") == 0) break;
        if (strlen(input) == 0) continue;

        /* Parse to get argv so we can log to AOF before executing */
        char input_copy[MAX_INPUT];
        strncpy(input_copy, input, sizeof(input_copy) - 1);
        input_copy[sizeof(input_copy) - 1] = '\0';

        char *tokens[MAX_TOKENS];
        int   argc = parse(input_copy, tokens);

        if (aof_path && argc > 0) {
            aof_append(argc, tokens);
        }

        /* Execute on the original input buffer (parse modifies in-place) */
        CommandResult res = run_command(db, input);

        if (res.message && strlen(res.message) > 0) {
            printf("%s\n", res.message);
        }
        freeResult(res);
    }

    aof_close();
    destroy_engine(db);
    printf("Bye!\n");
}
