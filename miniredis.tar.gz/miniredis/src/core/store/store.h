#ifndef STORE_H
#define STORE_H

#include "../object.h"

typedef struct Entry {
    char        *key;
    Object      *value;
    struct Entry *next;
} Entry;

typedef struct Store {
    Entry **buckets;
    int     size;
} Store;

/* core */
Store*  createStore(int size);
void    freeStore(Store *store);
void    setKey(Store *store, const char *key, Object *value);
Object* getKey(Store *store, const char *key);
void    deleteKey(Store *store, const char *key);

/* string ops */
char* getStringKey(Store *store, const char *key);

/* list ops */
int   lpushKey(Store *store, const char *key, const char *value);
char* lpopKey(Store *store, const char *key);
char* lrangeKey(Store *store, const char *key);
int   rpushKey(Store *store, const char *key, const char *value);
char* rpopKey(Store *store, const char *key);

/* set ops */
int   saddKey(Store *store, const char *key, const char *value);
int   sismemberKey(Store *store, const char *key, const char *value);
char* smembersKey(Store *store, const char *key);

/* hash ops */
int   hsetKey(Store *store, const char *key, const char *field, const char *value);
char* hgetKey(Store *store, const char *key, const char *field);
char* hgetallKey(Store *store, const char *key);

#endif
