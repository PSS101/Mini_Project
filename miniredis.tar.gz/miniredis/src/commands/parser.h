#ifndef PARSER_H
#define PARSER_H

#define MAX_TOKENS 10

int parse(char *input, char *tokens[]);

#endif
